---
description: Bridge a concept across domains including science, math, philosophy, code, law, history, psychology, medicine, arts, and politics so the learner sees what transfers and what does not.
args: <topic>
section: Teaching Workflows
topLevelCli: true
---
Bridge the following concept across domains: $@

Structure:

1. Define the core invariant idea.
2. Show how that idea appears in at least two domains.
3. Point out where the analogy stops working.
4. End with one ephemeral OpenUI `question` that checks transfer, then stop and wait for the learner's submitted answer.
