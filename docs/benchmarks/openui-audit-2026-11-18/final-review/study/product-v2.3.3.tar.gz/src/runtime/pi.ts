import { MODEL_CHOICES, SERVICE_ENDPOINTS } from "../../packages/runtime-config/src/index.js";
import { existsSync, statSync, readFileSync } from "node:fs";
import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";
import { homedir } from "node:os";

import { DEFAULT_PI_PROVIDER, FALLBACK_PI_MODELS, type KeatingConfig, loadKeatingConfig, mergePiDefaultsWithOverrides } from "../core/config.js";
import { ensureProjectScaffold } from "../core/project.js";
import { sessionsDir, configDir } from "../core/paths.js";
import { isCurrentAccountSyncDirectory } from "../core/account-sync-local.js";
import { assertDefaultProfileSessionPath, assertProfileSessionPath, learnerProfileEnvironment, selectedLearnerProfile, withLearnerProfileArgs } from "../core/learner-profile-selection.js";
import {
  PROVIDER_ENV_KEYS,
  envWithProviderAliases,
  providerIsConfigured,
  providerSetupMessage
} from "../core/provider-auth.js";
import { normalizePiPackages } from "../core/pi-packages.js";
import { KeatingPtyRpcClient, type KeatingRpcExtensionUiResponse } from "./pty-rpc-client.js";
import { CLASSIC_PI_TOOL_POLICY, OPEN_TUI_TOOL_POLICY, runtimeToolList } from "./tool-policy.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

function resolvePackageRoot(): string {
  const override = process.env.KEATING_PACKAGE_ROOT_OVERRIDE;
  if (override) return resolve(override);

  const normalizedDir = __dirname.replace(/\\/g, "/");
  return normalizedDir.includes("/dist/src/runtime")
    ? join(__dirname, "..", "..", "..")
    : join(__dirname, "..", "..");
}

export interface AiRuntimeDetails {
  kind: "binary" | "embedded-keating";
  command: string;
  cliPath?: string;
}

export interface AiRuntimeReport {
  selected: AiRuntimeDetails | null;
  standalone: AiRuntimeDetails | null;
  embedded: AiRuntimeDetails | null;
  preference: "standalone-only" | "prefer-standalone" | "embedded-only";
}

function missingRuntimeMessage(report: AiRuntimeReport): string {
  if (report.preference === "standalone-only") {
    return [
      "Keating is configured for standalone-only but no `pi` AI agent binary was found on PATH.",
      "",
      "Recover with one of:",
      "  npm install -g @earendil-works/pi-coding-agent",
      "  keating setup",
      "  edit keating.config.json and set pi.runtimePreference to prefer-standalone"
    ].join("\n");
  }

  if (report.preference === "embedded-only") {
    return [
      "Keating is configured for embedded-only but no embedded AI agent was found.",
      "",
      "Recover with one of:",
      "  npm install -g @earendil-works/pi-coding-agent",
      "  keating setup",
      "  npm install -g keating"
    ].join("\n");
  }

  return [
    "Could not find an AI runtime.",
    "",
    "Recover with one of:",
    "  npm install -g @earendil-works/pi-coding-agent",
    "  npm install -g keating",
    "  curl -fsSL https://raw.githubusercontent.com/Diogenesoftoronto/keating/main/scripts/install/install.sh | bash"
  ].join("\n");
}

function resolveStandaloneAgent(): AiRuntimeDetails | null {
  const result = spawnSync("which", ["pi"], { encoding: "utf8", env: process.env });
  if (result.status === 0 && result.stdout.trim()) {
    const command = result.stdout.trim();
    const versionResult = spawnSync(command, ["--version"], { encoding: "utf8", env: process.env });
    if (versionResult.status === 0 && /^\d+\.\d+\.\d+/.test(versionResult.stdout.trim())) {
      return {
        kind: "binary",
        command
      };
    }
  }
  return null;
}

const CLI_AGENT_PACKAGES = [
  ["@earendil-works", "pi-coding-agent"],
  ["@interleavelove", "keating-coding-agent"],
  ["@mariozechner", "pi-coding-agent"],
];

const ZYPHRA_PI_PROVIDER = {
  baseUrl: SERVICE_ENDPOINTS.zyphra,
  api: "openai-completions",
  apiKey: "$ZYPHRA_API_KEY",
  models: [
    { id: MODEL_CHOICES.piProviders.zyphra[0].value, name: MODEL_CHOICES.piProviders.zyphra[0].label }
  ]
} as const;

const MINIMAX_PI_PROVIDER = {
  baseUrl: SERVICE_ENDPOINTS.minimax,
  api: "openai-completions",
  apiKey: "$MINIMAX_API_KEY",
	compat: { supportsDeveloperRole: false, supportsReasoningEffort: false },
  models: [
	{
		id: MODEL_CHOICES.piProviders.minimax[0].value, name: MODEL_CHOICES.piProviders.minimax[0].label, reasoning: true,
		input: ["text"], contextWindow: 204_800, maxTokens: 32_768,
		cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }
	},
    { id: MODEL_CHOICES.piProviders.minimax[1].value, name: MODEL_CHOICES.piProviders.minimax[1].label, reasoning: true }
  ]
} as const;

const EXTRA_PI_PROVIDERS: Record<string, { envKey: string; provider: unknown }> = {
  zyphra: { envKey: "ZYPHRA_API_KEY", provider: ZYPHRA_PI_PROVIDER },
  minimax: { envKey: "MINIMAX_API_KEY", provider: MINIMAX_PI_PROVIDER }
};

export async function syncExtraProviders(cwd: string, env: NodeJS.ProcessEnv): Promise<void> {
  const active = Object.entries(EXTRA_PI_PROVIDERS).filter(([, entry]) => env[entry.envKey]);
  if (active.length === 0) return;

  const modelsPath = join(configDir(cwd), "models.json");
  let existing: Record<string, unknown> = {};
  try {
    const raw = await readFile(modelsPath, "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      existing = parsed as Record<string, unknown>;
    }
  } catch {
    existing = {};
  }

  const providers = { ...((existing.providers as Record<string, unknown>) ?? {}) };
  for (const [name, entry] of active) {
    providers[name] = entry.provider;
  }
  const merged = { ...existing, providers };
  await mkdir(configDir(cwd), { recursive: true });
  await writeFile(modelsPath, `${JSON.stringify(merged, null, 2)}\n`, "utf8");
}

async function syncPiSettings(cwd: string, config: KeatingConfig): Promise<void> {
  const agentDir = configDir(cwd);
  const settingsPath = join(agentDir, "settings.json");
  let settings: Record<string, unknown> = {};

  try {
    const parsed = JSON.parse(await readFile(settingsPath, "utf8"));
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      settings = parsed as Record<string, unknown>;
    }
  } catch {
    settings = {};
  }

  const quietStartup = !config.debug.consoleSummary;
  const nextSettings: Record<string, unknown> = { ...settings, quietStartup };
  if (Array.isArray(config.pi.packages)) {
    nextSettings.packages = normalizePiPackages(config.pi.packages);
  }
  if (JSON.stringify(settings) === JSON.stringify(nextSettings)) return;

  await mkdir(agentDir, { recursive: true });
  await writeFile(settingsPath, `${JSON.stringify(nextSettings, null, 2)}\n`, "utf8");
}

export interface ProviderAuthSelection {
  provider?: string;
  model?: string;
  env: NodeJS.ProcessEnv;
  note?: string;
  missingProvider?: string;
}

function hasFlag(args: string[], flag: string): boolean {
  return args.includes(flag) || args.some((arg) => arg.startsWith(`${flag}=`));
}

function flagValue(args: string[], flag: string): string | undefined {
  const equalsArg = args.find((arg) => arg.startsWith(`${flag}=`));
  if (equalsArg) return equalsArg.slice(flag.length + 1);
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : undefined;
}

export function selectAuthenticatedProvider(cwd: string, config: KeatingConfig, args: string[]): ProviderAuthSelection {
  const env = envWithProviderAliases(process.env);
  if (hasFlag(args, "--list-models") || hasFlag(args, "--list-providers")) return { env };

  const hasExplicitProvider = hasFlag(args, "--provider");
  const hasExplicitModel = hasFlag(args, "--model");
  const hasExplicitApiKey = hasFlag(args, "--api-key");
  const configuredProvider = config.pi.defaultProvider ?? DEFAULT_PI_PROVIDER;

  if (hasExplicitProvider) {
    const provider = flagValue(args, "--provider");
    if (provider && !hasExplicitApiKey && PROVIDER_ENV_KEYS[provider] && !providerIsConfigured(cwd, env, provider)) {
      return { env, note: providerSetupMessage(provider), missingProvider: provider };
    }
    return { env };
  }

  const candidates = [configuredProvider, "notorganic", "google", "openai", "anthropic", "openrouter", "zyphra", "minimax"].filter((provider, index, all) =>
    provider && all.indexOf(provider) === index
  );
  const selected = candidates.find((provider) => providerIsConfigured(cwd, env, provider));
  if (!selected) {
    return {
      env,
      missingProvider: configuredProvider,
      note: [
      providerSetupMessage(configuredProvider),
      "",
      "Keating also checked for Not Organic, OpenAI, Anthropic, OpenRouter, Zyphra, and MiniMax credentials and did not find them.",
      "Hosted fallback:",
      "  keating login (five-minute Not Organic infer:balanced capability)",
      "Supported fallback env vars:",
      "  GEMINI_API_KEY or GOOGLE_API_KEY",
      "  OPENAI_API_KEY",
      "  ANTHROPIC_API_KEY or ANTHROPIC_OAUTH_TOKEN",
      "  OPENROUTER_API_KEY (free models available at https://openrouter.ai)",
      "  ZYPHRA_API_KEY (ZAYA1-8B via https://cloud.zyphra.com)",
      `  MINIMAX_API_KEY (${MODEL_CHOICES.webCompatibility.minimax[1].value} via https://platform.minimax.io)`
    ].join("\n")
    };
  }

  if (selected === configuredProvider) return { env };

  return {
    provider: selected,
    model: hasExplicitModel ? undefined : FALLBACK_PI_MODELS[selected],
    env,
    note: `No credentials found for "${configuredProvider}". Using configured ${selected} credentials instead.`
  };
}

export function resolveNotOrganicProviderExtensionPath(): string {
  const packageRoot = resolvePackageRoot();
  const isDist = __dirname.replace(/\\/g, "/").includes("/dist/src/runtime");
  const built = isDist
    ? join(__dirname, "..", "pi", "notorganic-provider-extension.js")
    : join(packageRoot, "dist", "src", "pi", "notorganic-provider-extension.js");
  if (isDist || existsSync(built)) return built;
  // Pi's extension loader uses jiti, so source-checkout commands can load the
  // one explicit TypeScript extension before the first build.
  return join(packageRoot, "src", "pi", "notorganic-provider-extension.ts");
}

function resolveAgentInNodeModules(nodeModulesDir: string): AiRuntimeDetails | null {
  for (const [scope, pkg] of CLI_AGENT_PACKAGES) {
    const cliPath = join(nodeModulesDir, scope, pkg, "dist", "cli.js");
    if (existsSync(cliPath)) {
      return { kind: "embedded-keating", command: process.execPath, cliPath };
    }
  }

  return null;
}

async function resolveEmbeddedAgent(packageRoot = resolvePackageRoot()): Promise<AiRuntimeDetails | null> {
  const local = resolveAgentInNodeModules(join(packageRoot, "node_modules"));
  if (local) return local;

  const base = join(homedir(), ".local", "share", "keating");
  const entries = await readdir(base, { withFileTypes: true }).catch(() => []);
  const dirs = entries
    .filter((entry: any) => entry.isDirectory())
    .map((entry: any) => entry.name)
    .sort()
    .reverse();

  for (const name of dirs) {
    for (const root of [join(base, name), join(base, name, "app")]) {
      const embedded = resolveAgentInNodeModules(join(root, "node_modules"));
      if (embedded) return embedded;
    }
  }

  for (const [scope, pkg] of CLI_AGENT_PACKAGES) {
    const globalPrefix = join(homedir(), ".local", "share", "mise", "installs", "node");
    const versionEntries = await readdir(globalPrefix, { withFileTypes: true }).catch(() => []);
    const versionDirs = versionEntries
      .filter((e: any) => e.isDirectory())
      .map((e: any) => e.name)
      .sort()
      .reverse();

    for (const ver of versionDirs) {
      const cliPath = join(globalPrefix, ver, "lib", "node_modules", scope, pkg, "dist", "cli.js");
      if (existsSync(cliPath)) {
        return { kind: "embedded-keating", command: process.execPath, cliPath };
      }
      const nmDir = join(globalPrefix, ver, "lib", "node_modules");
      const nmEntries = await readdir(nmDir, { withFileTypes: true }).catch(() => []);
      const nmDirs = nmEntries.filter((e: any) => e.isDirectory() || (e.isSymbolicLink() && (() => { try { return statSync(join(nmDir, e.name)).isDirectory(); } catch { return false; } })()));
      for (const nmEntry of nmDirs) {
        const nested = join(nmDir, nmEntry.name, "node_modules", scope, pkg, "dist", "cli.js");
        if (existsSync(nested)) {
          return { kind: "embedded-keating", command: process.execPath, cliPath: nested };
        }
      }
    }

    const bunGlobal = join(homedir(), ".bun", "install", "global", "node_modules", scope, pkg, "dist", "cli.js");
    if (existsSync(bunGlobal)) {
      return { kind: "embedded-keating", command: process.execPath, cliPath: bunGlobal };
    }
  }

  return null;
}

export async function detectAiRuntime(cwd: string): Promise<AiRuntimeReport> {
  const config = await loadKeatingConfig(cwd);
  const standalone = resolveStandaloneAgent();
  const embedded = await resolveEmbeddedAgent();

  let selected: AiRuntimeDetails | null = null;
  switch (config.pi.runtimePreference) {
    case "embedded-only":
      selected = embedded;
      break;
    case "prefer-standalone":
      selected = standalone ?? embedded;
      break;
    case "standalone-only":
    default:
      selected = standalone;
      break;
  }

  return {
    selected,
    standalone,
    embedded,
    preference: config.pi.runtimePreference
  };
}

export async function launchShell(cwd: string, args: string[]): Promise<number> {
  return withLearnerProfileArgs(cwd, args, (selectedArgs) => launchSelectedShell(cwd, selectedArgs));
}

function validateProfileSessionArgs(cwd: string, args: string[]): void {
  const name = selectedLearnerProfile(cwd);
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index]!;
    if (arg === "--") break;
    for (const flag of ["--session", "--session-dir"]) {
      const value = arg === flag ? args[index + 1] : arg.startsWith(`${flag}=`) ? arg.slice(flag.length + 1) : undefined;
      if (value === undefined) continue;
      if (flag === "--session-dir") {
        if (isCurrentAccountSyncDirectory(cwd, resolve(cwd, value))) continue;
        if (name && resolve(cwd, value) !== resolve(sessionsDir(cwd))) throw new Error("--session-dir cannot override the selected learner profile.");
        if (!name) assertDefaultProfileSessionPath(join(cwd, ".keating", "profiles"), resolve(cwd, value));
      } else if (!/^[0-9a-f-]+$/i.test(value)) {
        if (name) assertProfileSessionPath(sessionsDir(cwd), resolve(cwd, value));
        else assertDefaultProfileSessionPath(join(cwd, ".keating", "profiles"), resolve(cwd, value));
      }
    }
  }
}

async function launchSelectedShell(cwd: string, args: string[]): Promise<number> {
  validateProfileSessionArgs(cwd, args);
  await ensureProjectScaffold(cwd);
  const config = await loadKeatingConfig(cwd);
  await syncPiSettings(cwd, config);
  await syncExtraProviders(cwd, process.env);
  const report = await detectAiRuntime(cwd);
  const runtime = report.selected;
  if (!runtime) {
    throw new Error(missingRuntimeMessage(report));
  }

  const packageRoot = resolvePackageRoot();
  const isDist = __dirname.replace(/\\/g, "/").includes("/dist/src/runtime");

  const extensionPath = isDist
    ? join(__dirname, "..", "pi", "hyper-teacher", "index.js")
    : join(packageRoot, "dist", "src", "pi", "hyper-teacher", "index.js");

  if (!existsSync(extensionPath)) {
    throw new Error([
      `Missing built extension: ${extensionPath}.`,
      "",
      "Recover with:",
      "  bun run build",
      "  npm run build",
      "",
      "If this came from an installed package, reinstall Keating:",
      "  npm install -g keating"
    ].join("\n"));
  }

  const promptDir = join(packageRoot, "pi", "prompts");
  const skillsDir = join(packageRoot, "pi", "skills");
  const systemPromptPath = join(packageRoot, "SYSTEM.md");
  const systemPrompt = readFileSync(systemPromptPath, "utf8");
  const authSelection = selectAuthenticatedProvider(cwd, config, args);
  if (authSelection.note) {
    console.error(authSelection.note);
  }

  const sharedArgs = mergePiDefaultsWithOverrides(config, [
    "--session-dir",
    sessionsDir(cwd),
    "--extension",
    extensionPath,
    "--prompt-template",
    promptDir,
    "--skill",
    skillsDir,
    // Keating supplies the base identity; Pi still adds skills and project context.
    "--system-prompt",
    systemPrompt,
    "--tools",
    runtimeToolList(CLASSIC_PI_TOOL_POLICY),
    ...args
  ], { provider: authSelection.provider, model: authSelection.model });

  const child =
    runtime.kind === "binary"
      ? spawn(runtime.command, sharedArgs, {
          cwd,
          stdio: "inherit",
          env: {
            ...learnerProfileEnvironment(cwd, authSelection.env),
            KEATING_AUTH_MISSING_PROVIDER: authSelection.missingProvider ?? "",
            PI_SKIP_VERSION_CHECK: process.env.PI_SKIP_VERSION_CHECK ?? "1",
            PI_CODING_AGENT_DIR: configDir(cwd)
          }
        })
      : spawn(runtime.command, [runtime.cliPath!, ...sharedArgs], {
          cwd,
          stdio: "inherit",
          env: {
            ...learnerProfileEnvironment(cwd, authSelection.env),
            KEATING_AUTH_MISSING_PROVIDER: authSelection.missingProvider ?? "",
            PI_SKIP_VERSION_CHECK: process.env.PI_SKIP_VERSION_CHECK ?? "1",
            PI_CODING_AGENT_DIR: configDir(cwd)
          }
        });

  return await new Promise<number>((resolvePromise, reject) => {
    child.on("error", reject);
    child.on("exit", (code: number | null) => resolvePromise(code ?? 0));
  });
}

/**
 * Start the same configured Pi runtime as `keating shell`, but over the
 * headless RPC transport so alternate hosts can render it. The caller owns
 * the returned client's lifecycle and must call `stop()`.
 */
export type KeatingRpcClient = KeatingPtyRpcClient;
export type { KeatingRpcExtensionUiResponse };

export async function launchRpcClient(cwd: string, args: string[] = []): Promise<KeatingRpcClient> {
  return withLearnerProfileArgs(cwd, args, (selectedArgs) => launchSelectedRpcClient(cwd, selectedArgs));
}

async function launchSelectedRpcClient(cwd: string, args: string[]): Promise<KeatingRpcClient> {
  validateProfileSessionArgs(cwd, args);
  const accountSessionDirectory = args.flatMap((arg, index) => {
    const value = arg === "--session-dir" ? args[index + 1] : arg.startsWith("--session-dir=") ? arg.slice("--session-dir=".length) : undefined;
    return value && isCurrentAccountSyncDirectory(cwd, resolve(cwd, value)) ? [resolve(cwd, value)] : [];
  }).at(-1);
  await ensureProjectScaffold(cwd);
  const config = await loadKeatingConfig(cwd);
  await syncPiSettings(cwd, config);
  await syncExtraProviders(cwd, process.env);

  const report = await detectAiRuntime(cwd);
  const runtime = report.selected;
  if (!runtime) throw new Error(missingRuntimeMessage(report));

  const packageRoot = resolvePackageRoot();
  const isDist = __dirname.replace(/\\/g, "/").includes("/dist/src/runtime");
  const extensionPath = isDist
    ? join(__dirname, "..", "pi", "hyper-teacher", "index.js")
    : join(packageRoot, "dist", "src", "pi", "hyper-teacher", "index.js");
  if (!existsSync(extensionPath)) {
    throw new Error(`Missing built extension: ${extensionPath}. Run bun run build before keating tui.`);
  }
  const rpcEntryPath = isDist
    ? join(__dirname, "pi-rpc-entry.js")
    : join(packageRoot, "dist", "src", "runtime", "pi-rpc-entry.js");
  if (!existsSync(rpcEntryPath)) {
    throw new Error(`Missing built RPC bootstrap: ${rpcEntryPath}. Run bun run build before keating tui.`);
  }
  const relayPath = isDist
    ? join(__dirname, "pi-pty-relay.js")
    : join(packageRoot, "dist", "src", "runtime", "pi-pty-relay.js");
  if (!existsSync(relayPath)) {
    throw new Error(`Missing built PTY relay: ${relayPath}. Run bun run build before keating tui.`);
  }

  const promptDir = join(packageRoot, "pi", "prompts");
  const skillsDir = join(packageRoot, "pi", "skills");
  const systemPrompt = readFileSync(join(packageRoot, "SYSTEM.md"), "utf8");
  const authSelection = selectAuthenticatedProvider(cwd, config, args);

  const sharedArgs = mergePiDefaultsWithOverrides(config, [
    "--no-extensions",
    "--session-dir",
    sessionsDir(cwd),
    "--extension",
    extensionPath,
    "--prompt-template",
    promptDir,
    "--skill",
    skillsDir,
    // Use the same Keating base prompt for the TUI and benchmark RPC path.
    "--system-prompt",
    systemPrompt,
    "--tools",
    runtimeToolList(OPEN_TUI_TOOL_POLICY),
    ...args,
  ], { provider: authSelection.provider, model: authSelection.model });

  const client = new KeatingPtyRpcClient({
    cliPath: rpcEntryPath,
    relayPath,
    cwd,
    args: sharedArgs,
    sessionDirectory: accountSessionDirectory ?? (selectedLearnerProfile(cwd) ? sessionsDir(cwd) : undefined),
    profilesDirectory: join(cwd, ".keating", "profiles"),
    env: {
      ...learnerProfileEnvironment(cwd, authSelection.env),
      // OpenTUI owns provider recovery end-to-end and must not redirect to
      // classic Pi's /login surface during extension startup.
      KEATING_AUTH_MISSING_PROVIDER: "",
      PI_SKIP_VERSION_CHECK: process.env.PI_SKIP_VERSION_CHECK ?? "1",
      PI_CODING_AGENT_DIR: configDir(cwd),
    } as Record<string, string>,
  });
  try {
    await client.start();
  } catch (error) {
    await client.stop();
    throw error;
  }
  return client;
}
