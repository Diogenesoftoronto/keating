import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import { basename, extname, join, relative } from "node:path";

import {
  benchmarksDir,
  evolutionDir,
  exportsDir,
  improvementsDir,
  mapsDir,
  plansDir,
  promptEvolutionDir,
  quizDir,
  sessionsDir,
  tracesDir,
  verificationsDir
} from "./paths.js";
import { slugify } from "./util.js";
import { cliSourceHash, cliSourceMessages, loadCliLearnerEvents, type CliSourceMessage } from "./learner-events.js";
import { computeCliRewardedTurns, type CliRewardedTurn, type CliQuizWithTiming } from "./session-reward.js";
import { loadCliQuizRecord } from "./quiz-grading.js";

export type ExportMode = "finetune";
export type ExportSource = "all" | "artifacts" | "sessions";
export type FineTuneFormat = "chatml" | "alpaca" | "both";

export interface KeatingExportOptions {
  mode: ExportMode;
  source: ExportSource;
  format: FineTuneFormat;
  outDir?: string;
  redact: boolean;
  minAssistantChars: number;
}

export interface KeatingExportManifest {
  schemaVersion: 1;
  mode: ExportMode;
  generatedAt: string;
  source: ExportSource;
  format: FineTuneFormat;
  counts: {
    artifactsRead: number;
    sessionsRead: number;
    examplesWritten: number;
    skipped: number;
    redactions: number;
    rewardedTurns?: number;
    scoredTurns?: number;
  };
  files: string[];
  warnings: string[];
}

interface FineTuneExample {
  id: string;
  source: "artifact" | "session";
  kind: string;
  instruction: string;
  input?: string;
  output: string;
  messages?: Array<{ role: "user" | "assistant"; content: string }>;
}

/**
 * One ChatML JSONL line = one conversation. Sessions become a single full
 * multi-turn conversation (system turns preserved) carrying a `keating`
 * envelope so the importer can reconstruct a faithful, resumable session;
 * lossless exports (redaction off) also embed the original full messages.
 */
interface FineTuneConversation {
  source: "artifact" | "session";
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
  envelope?: {
    title?: string;
    sessionId?: string;
    source?: string;
    model?: unknown;
    thinkingLevel?: string;
    messages?: unknown[];
  };
}

interface BuildResult {
  rewardedTurns: CliRewardedTurn[];
  examples: FineTuneExample[];
  conversations: FineTuneConversation[];
  corpusSections: string[];
  artifactsRead: number;
  sessionsRead: number;
  skipped: number;
  redactions: number;
  warnings: string[];
}

function createBuildResult(): BuildResult {
  return {
    rewardedTurns: [],
    examples: [],
    conversations: [],
    corpusSections: [],
    artifactsRead: 0,
    sessionsRead: 0,
    skipped: 0,
    redactions: 0,
    warnings: [],
  };
}

const DEFAULT_OPTIONS: KeatingExportOptions = {
  mode: "finetune",
  source: "all",
  format: "both",
  redact: true,
  minAssistantChars: 80,
};

const SECRET_PATTERNS: RegExp[] = [
  /\bsk-ant-[A-Za-z0-9_-]{12,}\b/g,
  /\bsk-[A-Za-z0-9_-]{12,}\b/g,
  /\bAIza[A-Za-z0-9_-]{16,}\b/g,
  /\bghp_[A-Za-z0-9_]{12,}\b/g,
  /\bBearer\s+[A-Za-z0-9._-]{12,}\b/gi,
  /^[A-Z][A-Z0-9_]*_API_KEY\s*=\s*.+$/gm,
  /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
];

const FINETUNE_TEMPLATE_DIR = new URL("./templates/finetune/", import.meta.url);

async function readFineTuneTemplate(path: string): Promise<string> {
  return readFile(new URL(path, FINETUNE_TEMPLATE_DIR), "utf8");
}

function normalizeOptions(options: KeatingExportOptions): KeatingExportOptions {
  return {
    ...DEFAULT_OPTIONS,
    ...options,
    minAssistantChars: Math.max(1, Math.floor(options.minAssistantChars || DEFAULT_OPTIONS.minAssistantChars)),
  };
}

function redactText(input: string, enabled: boolean): { text: string; count: number } {
  if (!enabled) return { text: input, count: 0 };
  let text = input;
  let count = 0;
  for (const pattern of SECRET_PATTERNS) {
    text = text.replace(pattern, () => {
      count += 1;
      return "[REDACTED]";
    });
  }
  return { text, count };
}

async function collectFiles(root: string): Promise<string[]> {
  const entries = await readdir(root, { withFileTypes: true }).catch(() => []);
  const files: string[] = [];
  for (const entry of entries) {
    const full = join(root, entry.name);
    if (entry.isDirectory()) {
      files.push(...await collectFiles(full));
    } else if (entry.isFile()) {
      files.push(full);
    }
  }
  return files.sort();
}

function titleFromPath(path: string): string {
  return basename(path, extname(path)).replace(/-/g, " ");
}

function artifactInstruction(kind: string, topic: string): string {
  switch (kind) {
    case "plan":
      return `Create a Keating-style Socratic lesson plan for ${topic}.`;
    case "quiz":
      return `Create retrieval practice and an answer key for ${topic}.`;
    case "map":
      return `Create a Mermaid concept map for ${topic}.`;
    case "verification":
      return `Create a verification checklist before teaching ${topic}.`;
    default:
      return `Create a Keating teaching artifact for ${topic}.`;
  }
}

function parseMessageText(message: any): string {
  const content = message?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content.map((part) => {
    if (typeof part === "string") return part;
    if (part?.type === "text" && typeof part.text === "string") return part.text;
    if (typeof part?.text === "string") return part.text;
    if (part?.type === "file" && typeof part.filename === "string") return `[Attachment: ${part.filename}]`;
    return "";
  }).filter(Boolean).join("\n");
}

function isBadAssistantText(text: string, message: any): boolean {
  if (message?.stopReason === "error") return true;
  return /__KEATING_ERROR__|authentication failed|no api key|stack trace|^\s*error:/i.test(text);
}

function sessionExamplesFromMessages(
  sessionId: string,
  messages: any[],
  options: KeatingExportOptions
): { examples: FineTuneExample[]; skipped: number; redactions: number; corpus: string } {
  const chatMessages: Array<{ role: "user" | "assistant"; content: string }> = [];
  let skipped = 0;
  let redactions = 0;

  for (const message of messages) {
    const rawRole = message?.role;
    const role = rawRole === "user" || rawRole === "user-with-attachments"
      ? "user"
      : rawRole === "assistant"
        ? "assistant"
        : null;
    if (!role) {
      skipped += 1;
      continue;
    }
    const rawText = parseMessageText(message).trim();
    if (!rawText) {
      skipped += 1;
      continue;
    }
    if (role === "assistant" && isBadAssistantText(rawText, message)) {
      skipped += 1;
      continue;
    }
    if (role === "assistant" && rawText.length < options.minAssistantChars) {
      skipped += 1;
      continue;
    }
    const redacted = redactText(rawText, options.redact);
    redactions += redacted.count;
    chatMessages.push({ role, content: redacted.text });
  }

  const examples: FineTuneExample[] = [];
  let pairIndex = 0;
  for (let i = 0; i < chatMessages.length - 1; i += 1) {
    const user = chatMessages[i];
    const assistant = chatMessages[i + 1];
    if (user?.role !== "user" || assistant?.role !== "assistant") continue;
    examples.push({
      id: `session-${slugify(sessionId)}-${pairIndex++}`,
      source: "session",
      kind: "conversation",
      instruction: user.content,
      output: assistant.content,
      messages: [user, assistant],
    });
  }

  const corpus = chatMessages.length
    ? [`## Session ${sessionId}`, ...chatMessages.map((m) => `**${m.role}:** ${m.content}`)].join("\n\n")
    : "";
  return { examples, skipped, redactions, corpus };
}

async function buildArtifactExamples(cwd: string, options: KeatingExportOptions): Promise<BuildResult> {
  const result = createBuildResult();

  const artifactRoots = [
    { kind: "plan", root: plansDir(cwd), include: (path: string) => path.endsWith(".md") },
    { kind: "quiz", root: quizDir(cwd), include: (path: string) => path.endsWith(".md") },
    { kind: "map", root: mapsDir(cwd), include: (path: string) => path.endsWith(".mmd") },
    { kind: "verification", root: verificationsDir(cwd), include: (path: string) => path.endsWith(".md") },
  ];

  for (const { kind, root, include } of artifactRoots) {
    for (const file of (await collectFiles(root)).filter(include)) {
      const raw = await readFile(file, "utf8").catch(() => "");
      result.artifactsRead += 1;
      if (!raw.trim()) {
        result.skipped += 1;
        continue;
      }
      const topic = titleFromPath(file).replace(/\s+answers$/i, "");
      const redacted = redactText(raw.trim(), options.redact);
      result.redactions += redacted.count;
      result.examples.push({
        id: `${kind}-${slugify(relative(cwd, file))}`,
        source: "artifact",
        kind,
        instruction: artifactInstruction(kind, topic),
        output: redacted.text,
        messages: [
          { role: "user", content: artifactInstruction(kind, topic) },
          { role: "assistant", content: redacted.text },
        ],
      });
      result.conversations.push({
        source: "artifact",
        messages: [
          { role: "user", content: artifactInstruction(kind, topic) },
          { role: "assistant", content: redacted.text },
        ],
      });
      result.corpusSections.push(`## ${kind}: ${relative(cwd, file)}\n\n${redacted.text}`);
    }
  }

  for (const root of [benchmarksDir(cwd), evolutionDir(cwd), promptEvolutionDir(cwd), improvementsDir(cwd), tracesDir(cwd)]) {
    for (const file of await collectFiles(root)) {
      const info = await stat(file).catch(() => null);
      if (!info || info.size > 512_000) continue;
      const raw = await readFile(file, "utf8").catch(() => "");
      if (raw.trim()) {
        const redacted = redactText(raw.trim(), options.redact);
        result.redactions += redacted.count;
        result.corpusSections.push(`## Reference: ${relative(cwd, file)}\n\n${redacted.text}`);
      }
    }
  }

  return result;
}

/** Builds one full, resumable conversation from a session's raw messages. */
function conversationFromSession(
  parsed: any,
  sessionId: string,
  messages: any[],
  options: KeatingExportOptions,
): { conversation: FineTuneConversation | null; redactions: number } {
  const turns: FineTuneConversation["messages"] = [];
  let redactions = 0;
  for (const message of messages) {
    const rawRole = message?.role;
    const role = rawRole === "user" || rawRole === "user-with-attachments"
      ? "user"
      : rawRole === "assistant"
        ? "assistant"
        : rawRole === "system"
          ? "system"
          : null;
    if (!role) continue;
    const text = parseMessageText(message).trim();
    if (!text) continue;
    // Keep the visible training turns at the same quality bar as the paired
    // examples (drop error/too-short assistant turns); the lossless envelope
    // below still carries the unfiltered originals for faithful resume.
    if (role === "assistant" && isBadAssistantText(text, message)) continue;
    if (role === "assistant" && text.length < options.minAssistantChars) continue;
    const redacted = redactText(text, options.redact);
    redactions += redacted.count;
    turns.push({ role, content: redacted.text });
  }
  const hasUser = turns.some((turn) => turn.role === "user");
  const hasAssistant = turns.some((turn) => turn.role === "assistant");
  if (!hasUser || !hasAssistant) return { conversation: null, redactions };
  return {
    conversation: {
      source: "session",
      messages: turns,
      envelope: {
        title: typeof parsed?.title === "string" ? parsed.title : undefined,
        sessionId,
        source: "keating-session-export",
        model: parsed?.model && typeof parsed.model === "object" ? parsed.model : undefined,
        thinkingLevel: typeof parsed?.thinkingLevel === "string" ? parsed.thinkingLevel : undefined,
        // Lossless resume: embed original messages only when not redacting.
        messages: options.redact ? undefined : messages,
      },
    },
    redactions,
  };
}

async function buildSessionExamples(cwd: string, options: KeatingExportOptions): Promise<BuildResult> {
  const result = createBuildResult();

  for (const file of (await collectFiles(sessionsDir(cwd))).filter((path) => /\.jsonl?$/.test(path))) {
    const raw = await readFile(file, "utf8").catch(() => "");
    if (!raw.trim()) continue;
    try {
      let parsed: any;
      let sourceMessages: CliSourceMessage[];
      if (file.endsWith(".jsonl")) {
        // Use Pi's branch semantics instead of flattening alternate histories.
        const { SessionManager } = await import("@earendil-works/pi-coding-agent");
        const session = SessionManager.open(file);
        const branch = session.getBranch();
        sourceMessages = cliSourceMessages(branch);
        parsed = { id: session.getSessionId(), title: session.getSessionName(),
          // Pi has hidden reasoning, tool arguments and tool results in its
          // native transcript. New exports expose visible text only.
          messages: sourceMessages };
      } else {
        parsed = JSON.parse(raw);
        const saved = Array.isArray(parsed?.messages) ? parsed.messages : Array.isArray(parsed) ? parsed : [];
        sourceMessages = cliSourceMessages(saved.map((message: any, index: number) => ({ type: "message",
          id: typeof message.id === "string" && /^[A-Za-z0-9_-]{1,200}$/.test(message.id) ? message.id : `unbound-${index}`,
          timestamp: message.timestamp, message })));
      }
      const messages = Array.isArray(parsed?.messages) ? parsed.messages : Array.isArray(parsed) ? parsed : [];
      if (!messages.length) {
        result.skipped += 1;
        continue;
      }
      result.sessionsRead += 1;
      const sessionId = typeof parsed?.id === "string" ? parsed.id : basename(file, ".json");
      const converted = sessionExamplesFromMessages(sessionId, messages, options);
      result.examples.push(...converted.examples);
      result.skipped += converted.skipped;
      result.redactions += converted.redactions;
      if (converted.corpus) result.corpusSections.push(converted.corpus);
      // One full, resumable conversation per session for the ChatML output.
      // (Redaction counts come from the example path above to avoid double counting.)
      const conv = conversationFromSession(parsed, sessionId, messages, options);
      if (conv.conversation) result.conversations.push(conv.conversation);
      // Legacy imports lacking stable IDs still export normally, but cannot
      // acquire proxy rewards from unrelated learner-state timestamp matches.
      if (!sourceMessages.length) sourceMessages = messages.flatMap((message: any, index: number) =>
        ["user", "assistant"].includes(message?.role) && parseMessageText(message).trim()
          ? [{ id: `unbound-${index}`, role: message.role, content: parseMessageText(message) }] : []);
      let rewards: CliRewardedTurn[];
      try {
        rewards = await rewardedSessionTurns(cwd, sessionId, sourceMessages);
      } catch {
        result.warnings.push(`Reward evidence unavailable for session: ${sessionId}`);
        rewards = computeCliRewardedTurns({ sessionId, messages: sourceMessages.map(message => ({ ...message, timestamp: undefined })), feedback: [], quizResults: [] });
      }
      for (const turn of rewards) {
        if (turn.completion.trim().length < options.minAssistantChars || isBadAssistantText(turn.completion, {})) continue;
        result.rewardedTurns.push({ ...turn,
          completion: redactText(turn.completion, options.redact).text,
          context: turn.context.map(message => ({ ...message, content: redactText(message.content, options.redact).text })),
        });
      }
    } catch {
      result.warnings.push(`Skipped invalid session JSON: ${relative(cwd, file)}`);
      result.skipped += 1;
    }
  }

  return result;
}

/** Source-bound event facts only; no heuristic joins against project-wide state. */
async function rewardedSessionTurns(cwd: string, sessionId: string, messages: CliSourceMessage[]): Promise<CliRewardedTurn[]> {
  const events = await loadCliLearnerEvents(cwd, sessionId);
  const bound = messages.map(message => {
    const source = events.find(event => event.kind === "message" && event.messageId === message.id
      && event.role === message.role && event.contentSha256 === cliSourceHash(message.content)
      && event.timestamp === message.timestamp);
    return { ...message, timestamp: source ? message.timestamp : undefined };
  });
  const ids = new Set(bound.filter(message => message.timestamp !== undefined && message.role === "assistant").map(message => message.id));
  const feedback = events.flatMap(event => event.kind === "feedback" && ids.has(event.messageId)
    ? [{ sessionId, messageId: event.messageId, sourceId: event.id, topic: event.topic, signal: event.signal, timestamp: new Date(event.timestamp).toISOString() }] : []);
  const quizResults: CliQuizWithTiming[] = [];
  for (const event of events) {
    if (event.kind !== "quiz" || !ids.has(event.messageId)) continue;
    const record = await loadCliQuizRecord(cwd, event.quizId).catch(() => null);
    if (!record || Date.parse(record.submission.createdAt) !== event.timestamp) continue;
    const questions = record.submission.quiz.questions;
    const total = questions.length;
    if (!total) continue;
    const exact = record.submission.objectiveResults;
    const allExact = questions.every(question => typeof exact[question.id] === "boolean");
    const reviewed = record.review?.source === "explicit-review" && record.review.score.total === total
      && Number.isFinite(record.review.score.correct) && record.review.score.correct >= 0 && record.review.score.correct <= total;
    if (!reviewed && !allExact) continue;
    const correct = reviewed ? record.review!.score.correct : questions.filter(question => exact[question.id]).length;
    const rawTiming = (record.submission as unknown as { timing?: { perQuestionMs?: Record<string, number> } }).timing;
    const perQuestionMs = Object.fromEntries(Object.entries(rawTiming?.perQuestionMs ?? {}).filter(([id, value]) =>
      questions.some(question => question.id === id) && typeof value === "number" && Number.isFinite(value) && value >= 0));
    quizResults.push({ sessionId, messageId: event.messageId,
      sourceId: `${event.id}@sha256:${cliSourceHash(JSON.stringify(reviewed ? record.review : record.submission))}`,
      topic: record.submission.quiz.slug, timestamp: new Date(event.timestamp).toISOString(), correct, total, score: correct / total,
      timing: { perQuestionMs } });
  }
  return computeCliRewardedTurns({ sessionId, messages: bound, feedback, quizResults });
}

function toChatMlJsonl(conversations: FineTuneConversation[]): string {
  return conversations.map((conversation) => JSON.stringify(
    conversation.envelope
      ? { messages: conversation.messages, keating: conversation.envelope }
      : { messages: conversation.messages },
  )).join("\n") + (conversations.length ? "\n" : "");
}

function toAlpacaJsonl(examples: FineTuneExample[]): string {
  return examples.map((example) => JSON.stringify({
    instruction: example.instruction,
    input: example.input ?? "",
    output: example.output,
  })).join("\n") + (examples.length ? "\n" : "");
}

function timestampSlug(date = new Date()): string {
  return date.toISOString().replace(/[:.]/g, "-");
}

export async function exportFineTuneDataset(
  cwd: string,
  inputOptions: KeatingExportOptions
): Promise<{ manifestPath: string; outDir: string; manifest: KeatingExportManifest }> {
  const options = normalizeOptions(inputOptions);
  if (options.mode !== "finetune") throw new Error(`Unsupported export mode: ${options.mode}`);

  const outDir = options.outDir ?? join(exportsDir(cwd), timestampSlug());
  await mkdir(join(outDir, "runpod"), { recursive: true });

  const parts: BuildResult[] = [];
  if (options.source === "all" || options.source === "artifacts") {
    parts.push(await buildArtifactExamples(cwd, options));
  }
  if (options.source === "all" || options.source === "sessions") {
    parts.push(await buildSessionExamples(cwd, options));
  }

  const examples = parts.flatMap((part) => part.examples);
  const conversations = parts.flatMap((part) => part.conversations);
  const warnings = parts.flatMap((part) => part.warnings);
  const skipped = parts.reduce((sum, part) => sum + part.skipped, 0);
  const redactions = parts.reduce((sum, part) => sum + part.redactions, 0);
  const artifactsRead = parts.reduce((sum, part) => sum + part.artifactsRead, 0);
  const sessionsRead = parts.reduce((sum, part) => sum + part.sessionsRead, 0);
  const rewardedTurns = parts.flatMap(part => part.rewardedTurns);

  if (examples.length === 0 && conversations.length === 0) {
    throw new Error("No fine-tuning examples found. Run keating plan, quiz, verify, or use Keating chat sessions first.");
  }

  const [
    requirementsText,
    unslothTrainScript,
    runpodReadme,
    runpodStartScript,
  ] = await Promise.all([
    readFineTuneTemplate("requirements.txt"),
    readFineTuneTemplate("unsloth_train.py"),
    readFineTuneTemplate("runpod/README.md"),
    readFineTuneTemplate("runpod/start.sh"),
  ]);

  const files: string[] = [];
  if (options.source !== "artifacts") {
    const path = join(outDir, "rewarded-turns.jsonl");
    await writeFile(path, rewardedTurns.map(turn => JSON.stringify(turn)).join("\n") + (rewardedTurns.length ? "\n" : ""), { mode: 0o600 });
    files.push(relative(cwd, path));
  }
  if (options.format === "chatml" || options.format === "both") {
    const path = join(outDir, "train.chatml.jsonl");
    await writeFile(path, toChatMlJsonl(conversations), "utf8");
    files.push(relative(cwd, path));
  }
  if (options.format === "alpaca" || options.format === "both") {
    const path = join(outDir, "train.alpaca.jsonl");
    await writeFile(path, toAlpacaJsonl(examples), "utf8");
    files.push(relative(cwd, path));
  }

  const corpusPath = join(outDir, "corpus.md");
  await writeFile(corpusPath, parts.flatMap((part) => part.corpusSections).join("\n\n---\n\n"), "utf8");
  files.push(relative(cwd, corpusPath));

  const requirementsPath = join(outDir, "requirements.txt");
  await writeFile(requirementsPath, requirementsText, "utf8");
  files.push(relative(cwd, requirementsPath));

  const trainPath = join(outDir, "unsloth_train.py");
  await writeFile(trainPath, unslothTrainScript, "utf8");
  files.push(relative(cwd, trainPath));

  const runpodReadmePath = join(outDir, "runpod", "README.md");
  await writeFile(runpodReadmePath, runpodReadme, "utf8");
  files.push(relative(cwd, runpodReadmePath));

  const runpodStartPath = join(outDir, "runpod", "start.sh");
  await writeFile(runpodStartPath, runpodStartScript, "utf8");
  files.push(relative(cwd, runpodStartPath));

  const manifest: KeatingExportManifest = {
    schemaVersion: 1,
    mode: "finetune",
    generatedAt: new Date().toISOString(),
    source: options.source,
    format: options.format,
    counts: {
      artifactsRead,
      sessionsRead,
      examplesWritten: examples.length,
      skipped,
      redactions,
      ...(options.source !== "artifacts" ? { rewardedTurns: rewardedTurns.length, scoredTurns: rewardedTurns.filter(turn => turn.scored).length } : {}),
    },
    files,
    warnings,
  };

  const manifestPath = join(outDir, "manifest.json");
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  manifest.files.unshift(relative(cwd, manifestPath));
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");

  return { manifestPath, outDir, manifest };
}
