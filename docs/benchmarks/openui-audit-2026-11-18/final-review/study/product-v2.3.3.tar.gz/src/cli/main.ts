import { DEFAULT_MODELS, FLINT_PREVIEW_PROFILE } from "../../packages/runtime-config/src/index.js";
import { relative } from "node:path";
import { join, resolve } from "node:path";
import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";

import { DEFAULT_KEATING_CONFIG, configPath, loadKeatingConfig, writeKeatingConfig } from "../core/config.js";
import { learnerStatePath } from "../core/paths.js";
import { learnerProfileEnvironment, withLearnerProfileArgs } from "../core/learner-profile-selection.js";
import { loadLearnerState, recordFeedback, saveLearnerState } from "../core/learner-state.js";
import {
  animateTopicArtifact,
  autoImproveArtifact,
  benchPolicyArtifact,
  promptEvalArtifact,
  currentPolicySummary,
  ensureProjectScaffold,
  evolvePolicyArtifact,
  evolvePromptArtifact,
  improveAccept,
  improveArtifact,
  improveHistory,
  improveReject,
  listArtifacts,
  mapTopicArtifact,
  planTopicArtifact,
  quizTopicArtifact,
  verifyTopicArtifact,
  timelineArtifact,
  dueTopicsArtifact,
  exportKeatingData,
  importKeatingData
} from "../core/project.js";
import type { ExportSource, FineTuneFormat } from "../core/export.js";
import type { FineTuneImportFormat } from "../core/import.js";
import { activeTeachingPrompt, teachingBenchmarkArtifact } from "../core/teaching-evolution.js";
import { getLearningCheck, listLearningChecks, startLearningCheck, submitLearningCheck } from "../core/learning-checks.js";
import { validateTeachingCases } from "../../shared/evolution/benchmark.js";
import type { TeachingCase } from "../../shared/evolution/contracts.js";
import type { LearningCheckAssistance, LearningCheckStage, LearningCheckTopic } from "../../shared/evolution/learning-checks.js";
import { detectAiRuntime, launchShell } from "../runtime/pi.js";
import { launchAccountSyncedShell, currentCliAccountSyncLocal, syncCliAccount } from "../core/account-sync.js";
import { loginAccountSync, logoutAccountSync, loadAccountSyncCredential } from "../core/account-sync-auth.js";
import { accountSyncSessionPath, withAccountSyncLease } from "../core/account-sync-local.js";
import { launchOpenTui } from "../tui/opentui-host.js";
import { shellHandoffArgs } from "../tui/shell-handoff.js";
import { serveWeb, type ServeWebOptions, type WebAgentRuntimeMode } from "./web.js";
import { webHelpText } from "./web-help.js";
import { runOpenUiDiagnosticCommand } from "./openui-diagnostics.js";
import { serveWebMcp } from "../mcp/server.js";
import { color, bold, cliCommands } from "../core/theme.js";
import { printAsciiHeader } from "../core/terminal.js";
import { applySourceEdit, rollbackEdits, editResultToMarkdown } from "../core/code-edit.js";
import { KEATING_VERSION } from "../core/version.js";
import {
  addConfiguredPiPackage,
  listConfiguredPiPackages,
  recommendedPiPackagesMarkdown,
  removeConfiguredPiPackage
} from "../core/pi-packages.js";
import {
  loginNotOrganic,
  logoutNotOrganic,
  NOTORGANIC_MODEL_ID,
  NOTORGANIC_PROVIDER_ID,
  notOrganicAuthStatus
} from "../core/notorganic-auth.js";

function printUsage(): void {
  printAsciiHeader();
  console.log(bold("primary", "Keating CLI") + "  " + color.dim + color.sepia + `v${KEATING_VERSION}` + color.reset);
  console.log(color.parchment + "The Hyperteacher — cognitive empowerment through Socratic AI." + color.reset);
  console.log("");
  console.log(cliCommands());
  console.log("");
  console.log(bold("primary", "General Commands"));
  console.log(`  ${color.primary}shell${color.reset}  [initial prompt...]  Launch the AI-powered hyperteacher shell`);
  console.log(`  ${color.primary}tui${color.reset}    [initial prompt...]  Launch the OpenTUI host over Pi RPC`);
  console.log(`  ${color.sepia}--profile=name${color.reset}  Select .keating/profiles/name.json with separate learner history`);
  console.log(`  ${color.primary}setup${color.reset}  [--yes]             Configure Keating for this project`);
  console.log(`  ${color.primary}profile${color.reset} [--name=…] [--image=…|--initials=…|--learner]  Configure TUI identity`);
  console.log(`  ${color.primary}login${color.reset}  [notorganic] [--manual|--status]  Connect five-minute hosted inference`);
  console.log(`  ${color.primary}logout${color.reset} [notorganic]             Remove the hosted capability`);
  console.log(`  ${color.primary}auth${color.reset}    status                   Inspect hosted capability status`);
  console.log(`  ${color.primary}doctor${color.reset}                    Inspect AI runtime and renderer configuration`);
  console.log(`  ${color.primary}package${color.reset} list|add|remove|recommended  Manage extra Pi packages`);
  console.log(`  ${color.primary}web${color.reset}     [port] [runtime options]  Start the browser UI; run ${color.primary}keating web --help${color.reset} for NodePod, host, external, and cloud setup`);
  console.log(`  ${color.primary}webmcp${color.reset}  [port] [--host=127.0.0.1]  Expose Keating tools over MCP Streamable HTTP`);
  console.log(`  ${color.primary}policy${color.reset}                    Print the active teaching policy`);
  console.log(`  ${color.primary}trace${color.reset}   [substring]        Browse debug traces and artifacts`);
  console.log("");
}

function teachingCommandHelp(command: "teaching-bench" | "auto-improve"): string {
  return [
    `Usage: keating ${command} [--cases <JSON pack>]${command === "auto-improve" ? " [--force]" : ""}`,
    "",
    command === "teaching-bench"
      ? "Execute the active tutor on training cases only. Validation and holdout cannot be requested here."
      : "Propose one teaching skill, execute paired validation and a sealed holdout, and activate only if both gates pass.",
    "--cases accepts a JSON array of independent TeachingCase records (at most 60).",
    "Evidence covers executed teaching behavior on synthetic cases; human learning remains unmeasured.",
    "Independent typed judge: first run keating login --judgement in this project.",
    "Set KEATING_EVOLUTION_JUDGE=notorganic-exploratory and KEATING_JUDGEMENT_MODEL=jev-1.13.0.",
    "Exploratory judgements are uncalibrated estimates; both activation gates remain required. Unset keeps the legacy judge.",
    "Measured calibration: use KEATING_EVOLUTION_JUDGE=notorganic with KEATING_EVOLUTION_CALIBRATION_FILE and KEATING_JUDGEMENT_CALIBRATION_SHA256.",
    ...(command === "auto-improve" ? ["--force overrides the 30-minute cooldown only. Consumed holdout evidence cannot be reused."] : []),
  ].join("\n");
}

async function teachingCommandOptions(cwd: string, args: string[], command: "teaching-bench" | "auto-improve") {
  let casesPath: string | undefined;
  let force = false;
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index]!;
    if (arg === "--force" && command === "auto-improve") { force = true; continue; }
    if (arg === "--cases" || arg.startsWith("--cases=")) {
      if (casesPath !== undefined) throw new Error("Pass --cases only once.");
      casesPath = arg === "--cases" ? args[++index] : arg.slice("--cases=".length);
      if (!casesPath || casesPath.startsWith("--")) throw new Error("--cases requires a JSON file path.");
      continue;
    }
    throw new Error(`Unsupported ${command} argument. ${command} evaluates a case pack; run keating ${command} --help.`);
  }
  let cases: TeachingCase[] | undefined;
  if (casesPath) {
    const text = await readFile(resolve(cwd, casesPath), "utf8");
    if (text.length > 1_000_000) throw new Error("Teaching case pack exceeds the 1 MB input limit.");
    let value: unknown;
    try { value = JSON.parse(text); } catch { throw new Error("Teaching case pack must be valid JSON."); }
    if (!Array.isArray(value) || value.length === 0 || value.length > 60) throw new Error("Teaching case pack must contain 1 to 60 case records.");
    for (const item of value) {
      if (!item || typeof item !== "object" || typeof item.id !== "string" || typeof item.family !== "string"
        || !["mathematics", "programming"].includes(item.domain)
        || !Array.isArray(item.messages) || !Array.isArray(item.rubric)
        || item.messages.some((message: unknown) => !message || typeof message !== "object" || !("content" in message) || typeof message.content !== "string")
        || item.rubric.some((criterion: unknown) => !criterion || typeof criterion !== "object"
          || !("id" in criterion) || typeof criterion.id !== "string"
          || !("description" in criterion) || typeof criterion.description !== "string"
          || !("critical" in criterion) || typeof criterion.critical !== "boolean")) {
        throw new Error("Invalid teaching case record. Expected id, family, domain, split, messages, and fixed rubric criteria.");
      }
    }
    cases = value as TeachingCase[];
    validateTeachingCases(cases);
  }
  return { cases, force };
}

async function runLearningCheckCommand(cwd: string, args: string[]): Promise<void> {
  if (!args.length || args.includes("--help") || args.includes("-h")) {
    console.log([
      "Usage: keating learning-check start <fractions|loop-bounds> [--learner <id>]",
      "       keating learning-check show <id>",
      "       keating learning-check list",
      "       keating learning-check submit <id> <precheck|immediate|delayed|transfer> --answers '<JSON object>' --assistance <none|assisted|unknown>",
      "",
      "Start records the active teaching revision. Submit answers keyed by the item IDs shown in the check.",
      "Recall opens one day after the postcheck; transfer opens seven days after it. Assistance is self-reported.",
    ].join("\n"));
    return;
  }
  const positionals: string[] = [];
  const flags = new Map<string, string>();
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index]!;
    if (!arg.startsWith("--")) { positionals.push(arg); continue; }
    const [flag, ...rest] = arg.split("=");
    if (!["--answers", "--assistance", "--learner"].includes(flag!)) throw new Error("Unknown learning-check option.");
    if (flags.has(flag!)) throw new Error("Pass each learning-check option only once.");
    const value = rest.length ? rest.join("=") : args[++index];
    if (!value || value.startsWith("--")) throw new Error(`${flag} requires a value.`);
    flags.set(flag!, value);
  }
  const [action, idOrTopic, requestedStage] = positionals;
  if (action === "start" && positionals.length === 2 && [...flags.keys()].every((flag) => flag === "--learner")) {
    if (idOrTopic !== "fractions" && idOrTopic !== "loop-bounds") throw new Error("Learning checks support fractions and loop-bounds.");
    const { revisionId } = await activeTeachingPrompt(cwd);
    const learnerId = flags.get("--learner") ?? (await loadLearnerState(learnerStatePath(cwd))).profile.id;
    console.log(JSON.stringify(await startLearningCheck(cwd, { topic: idOrTopic as LearningCheckTopic, revisionId, learnerId }), null, 2));
    return;
  }
  if (action === "show" && positionals.length === 2 && !flags.size) {
    console.log(JSON.stringify(await getLearningCheck(cwd, idOrTopic!), null, 2));
    return;
  }
  if (action === "list" && positionals.length === 1 && !flags.size) {
    console.log(JSON.stringify(await listLearningChecks(cwd), null, 2));
    return;
  }
  if (action === "submit" && positionals.length === 3 && flags.size === 2 && flags.has("--answers") && flags.has("--assistance")) {
    const assistance = flags.get("--assistance")!;
    if (!["none", "assisted", "unknown"].includes(assistance)) throw new Error("Assistance must be none, assisted, or unknown.");
    if (!["precheck", "immediate", "delayed", "transfer"].includes(requestedStage!)) throw new Error("Unknown learning-check stage.");
    let answers: unknown;
    try { answers = JSON.parse(flags.get("--answers")!); } catch { throw new Error("--answers must be a JSON object mapping item IDs to answer strings."); }
    if (!answers || typeof answers !== "object" || Array.isArray(answers) || Object.values(answers).some((answer) => typeof answer !== "string")) {
      throw new Error("--answers must map item IDs to answer strings.");
    }
    console.log(JSON.stringify(await submitLearningCheck(cwd, idOrTopic!, {
      stage: requestedStage as LearningCheckStage, assistance: assistance as LearningCheckAssistance, answers: answers as Record<string, string>,
    }), null, 2));
    return;
  }
  throw new Error("Invalid learning-check arguments. Run keating learning-check --help.");
}

function validateNotOrganicProvider(provider: string, command: "login" | "logout"): string {
  if (provider !== NOTORGANIC_PROVIDER_ID) {
    throw new Error(`Unsupported ${command} provider: ${provider}. Only Not Organic hosted inference is supported.`);
  }
  return provider;
}

function printNotOrganicLoginUsage(): void {
  console.log([
    "Usage: keating login [notorganic] [--manual|--headless] [--model=inkling-2-small|balanced|flint] [--tutor] [--judgement] | --status",
    "",
    `Connect a five-minute Not Organic infer:${NOTORGANIC_MODEL_ID} capability.`,
    "  --manual, --headless  Print the URL and read the callback from stdin",
    "  --judgement           Also request judgement:evaluate access",
    "  --tutor               Also request fresh Ampersand Tutor consultation consent",
    "  --model=flint         Request fresh Flint preview consent (gateway activation required)",
    "  --status              Show the current capability status",
    "  --help, -h            Show this help without starting login"
  ].join("\n"));
}

function printNotOrganicLogoutUsage(): void {
  console.log([
    "Usage: keating logout [notorganic]",
    "",
    "Remove only the project-scoped Not Organic capability.",
    "  --help, -h  Show this help without removing credentials"
  ].join("\n"));
}

function unknownNotOrganicOption(command: "login" | "logout", option: string): Error {
  return new Error(`Unknown ${command} option: ${option}. Run \`keating ${command} --help\`.`);
}

function openAuthorizationUrl(url: string): void {
  const command = process.platform === "darwin"
    ? "open"
    : process.platform === "win32" ? "rundll32.exe" : "xdg-open";
  const args = process.platform === "win32" ? ["url.dll,FileProtocolHandler", url] : [url];
  try {
    const child = spawn(command, args, { detached: true, stdio: "ignore" });
    child.once("error", () => {
      console.error(`${color.sepia}Could not open a browser. Open the authorization URL above, or rerun with --manual.${color.reset}`);
    });
    child.unref();
  } catch {
    console.error(`${color.sepia}Could not open a browser. Open the authorization URL above, or rerun with --manual.${color.reset}`);
  }
}

async function readPipedManualCallback(signal: AbortSignal): Promise<string> {
  if (signal.aborted) throw new Error("Not Organic login input was cancelled.");
  return await new Promise<string>((resolveInput, rejectInput) => {
    let value = "";
    let settled = false;
    const wasPaused = process.stdin.isPaused();
    const cleanup = () => {
      process.stdin.off("data", onData);
      process.stdin.off("end", onEnd);
      process.stdin.off("error", onError);
      signal.removeEventListener("abort", onAbort);
      if (wasPaused) process.stdin.pause();
    };
    const finish = (result: { value: string } | { error: Error }) => {
      if (settled) return;
      settled = true;
      cleanup();
      if ("error" in result) rejectInput(result.error);
      else resolveInput(result.value.trim());
    };
    const onData = (chunk: string | Buffer) => { value += String(chunk); };
    const onEnd = () => finish({ value });
    const onError = (error: Error) => finish({ error });
    const onAbort = () => finish({ error: new Error("Not Organic login input was cancelled.") });
    process.stdin.on("data", onData);
    process.stdin.once("end", onEnd);
    process.stdin.once("error", onError);
    signal.addEventListener("abort", onAbort, { once: true });
    process.stdin.resume();
  });
}

async function readManualCallback(signal: AbortSignal): Promise<string> {
  if (!process.stdin.isTTY) {
    return await readPipedManualCallback(signal);
  }
  const readline = await import("node:readline/promises");
  const terminal = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    return (await terminal.question(
      "Paste the complete callback URL (or code#state): ",
      { signal }
    )).trim();
  } finally {
    terminal.close();
  }
}

function shouldUseManualLogin(args: string[]): boolean {
  if (args.includes("--manual") || args.includes("--headless")) return true;
  if (!process.stdin.isTTY || !process.stdout.isTTY || process.env.CI) return true;
  return process.platform === "linux" && !process.env.DISPLAY && !process.env.WAYLAND_DISPLAY;
}

function printNotOrganicStatus(cwd: string): void {
  const status = notOrganicAuthStatus(cwd);
  if (status.expired) {
    console.log(`${color.sepia}Not Organic is not configured: the stored five-minute capability expired.${color.reset}`);
    const judgement = status.scope?.split(" ").includes("judgement:evaluate");
    console.log(`Run ${color.primary}keating login${judgement ? " --judgement" : ""}${color.reset} to reconnect.`);
    return;
  }
  if (!status.configured) {
    console.log(`${color.sepia}Not Organic is not connected for this project.${color.reset}`);
    console.log(`Run ${color.primary}keating login${color.reset} to enable infer:balanced.`);
    return;
  }
  console.log(`${color.ok}Not Organic is connected.${color.reset} ${status.scope} · ${status.secondsRemaining ?? 0}s remaining`);
}

async function runLoginCommand(cwd: string, args: string[]): Promise<void> {
  if (args.includes("--help") || args.includes("-h")) {
    printNotOrganicLoginUsage();
    return;
  }
  const modelSelections: string[] = [];
  args = args.filter((arg, index, all) => {
    if (arg === "--model") {
      const value = all[index + 1];
      if (!value || value.startsWith("-")) throw new Error("--model requires inkling-2-small, balanced, or flint.");
      modelSelections.push(value);
      return false;
    }
    if (index > 0 && all[index - 1] === "--model") return false;
    if (arg.startsWith("--model=")) { modelSelections.push(arg.slice("--model=".length)); return false; }
    return true;
  });
  if (modelSelections.length > 1) throw new Error("Specify --model only once.");
  const model = modelSelections[0] ?? NOTORGANIC_MODEL_ID;
  if (model !== NOTORGANIC_MODEL_ID && model !== "balanced" && model !== FLINT_PREVIEW_PROFILE.id) throw new Error("--model requires inkling-2-small, balanced, or flint.");
  const knownFlags = new Set(["--manual", "--headless", "--status", "--judgement", "--tutor"]);
  const unknownFlag = args.find((arg) => arg.startsWith("-") && !knownFlags.has(arg));
  if (unknownFlag) throw unknownNotOrganicOption("login", unknownFlag);
  const positionals = args.filter((arg) => !arg.startsWith("-"));
  const statusPositional = positionals[0] === "status";
  if (positionals.length > 1) {
    throw new Error(`Unexpected login argument: ${positionals[1]}. Run \`keating login --help\`.`);
  }
  const status = args.includes("--status") || statusPositional;
  const manual = shouldUseManualLogin(args);
  const provider = statusPositional
    ? NOTORGANIC_PROVIDER_ID
    : positionals[0] ?? NOTORGANIC_PROVIDER_ID;
  validateNotOrganicProvider(provider, "login");
  if (status && (args.includes("--manual") || args.includes("--headless") || args.includes("--judgement") || args.includes("--tutor") || modelSelections.length)) {
    throw new Error("Not Organic login status cannot be combined with --manual, --headless, --model, --tutor, or --judgement.");
  }
  if (status) {
    printNotOrganicStatus(cwd);
    return;
  }
  const result = await loginNotOrganic(cwd, {
    onAuth: ({ url, instructions }) => {
      console.log(`${bold("primary", "Not Organic login")}`);
      if (instructions) console.log(`${color.sepia}${instructions}${color.reset}`);
      console.log(url);
      if (!manual) openAuthorizationUrl(url);
    },
    onProgress: (message) => console.error(`${color.sepia}${message}${color.reset}`),
    ...(manual ? { onManualCodeInput: readManualCallback } : {})
  }, { model, judgement: args.includes("--judgement"), tutor: args.includes("--tutor") });

  const config = await loadKeatingConfig(cwd);
  await writeKeatingConfig(cwd, {
    ...config,
    pi: {
      ...config.pi,
      defaultProvider: NOTORGANIC_PROVIDER_ID,
      defaultModel: result.model
    }
  });
  console.log(`${color.ok}${result.message}${color.reset}`);
  console.log(`Run ${color.primary}keating shell${color.reset} now to use ${result.provider}/${result.model}.`);
}

function runLogoutCommand(cwd: string, args: string[]): void {
  if (args.includes("--help") || args.includes("-h")) {
    printNotOrganicLogoutUsage();
    return;
  }
  const unknownFlag = args.find((arg) => arg.startsWith("-"));
  if (unknownFlag) throw unknownNotOrganicOption("logout", unknownFlag);
  if (args.length > 1) {
    throw new Error(`Unexpected logout argument: ${args[1]}. Run \`keating logout --help\`.`);
  }
  validateNotOrganicProvider(args[0] ?? NOTORGANIC_PROVIDER_ID, "logout");
  const removed = logoutNotOrganic(cwd);
  console.log(removed
    ? `${color.ok}Removed the project-scoped Not Organic capability.${color.reset}`
    : `${color.sepia}Not Organic was not connected for this project.${color.reset}`);
}

function normalizeTopLevelShellArgs(args: string[]): string[] | null {
  if (args.length === 0 || !args[0]?.startsWith("-") || args[0] === "--help" || args[0] === "-h") return null;
  return args.map((arg) => arg === "--list-model" ? "--list-models" : arg);
}

function commandUsage(command: string, example: string): Error {
  return new Error([
    `${command} needs more input.`,
    "",
    "Recover with:",
    `  ${example}`,
    "  keating help"
  ].join("\n"));
}

function unknownCommand(command: string): Error {
  return new Error([
    `Unknown command: ${command}`,
    "",
    "Recover with:",
    "  keating help",
    "  keating setup",
    "  keating shell",
    "",
    "For model discovery, use:",
    "  keating --list-models"
  ].join("\n"));
}

function optionValue(args: string[], name: string): string | undefined {
  const prefix = `${name}=`;
  const withEquals = args.find((arg) => arg.startsWith(prefix));
  if (withEquals) return withEquals.slice(prefix.length);
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : undefined;
}

function firstPositional(args: string[]): string | undefined {
  return args.find((arg) => !arg.startsWith("-"));
}

function firstWebPositional(args: string[]): string | undefined {
  const optionsWithValues = new Set([
    "--remote-provider",
    "--remote-endpoint",
    "--remote-region",
    "--remote-snapshot",
    "--remote-cpu",
    "--remote-memory",
    "--remote-disk",
    "--cloud-endpoint"
  ]);

  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (!arg) continue;
    if (optionsWithValues.has(arg)) {
      i += 1;
      continue;
    }
    if (arg.startsWith("--") && arg.includes("=")) continue;
    if (!arg.startsWith("-")) return arg;
  }
  return undefined;
}

function parseWebCommand(args: string[]): { port: number; options: ServeWebOptions } {
  const modes: WebAgentRuntimeMode[] = [];
  if (args.includes("--browser-only-agent")) modes.push("browser-only");
  if (args.includes("--host")) modes.push("host");
  if (args.includes("--remote")) modes.push("remote");
  if (args.includes("--cloud")) modes.push("cloud");
  if (modes.length > 1) {
    throw new Error("Choose only one web agent mode: --browser-only-agent, --host, --remote, or --cloud.");
  }

  const portArg = firstWebPositional(args);
  const port = portArg ? parseInt(portArg, 10) : 3000;
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`Invalid port: "${portArg}". Must be an integer between 1 and 65535.`);
  }

  const remoteProvider = optionValue(args, "--remote-provider");
  // Preserve the pre-2.4 host spelling while normalizing it to the explicit mode.
  const requestedMode = modes[0] ?? "browser-only";
  const agentRuntimeMode = requestedMode === "remote" && remoteProvider === "host"
    ? "host"
    : requestedMode;

  return {
    port,
    options: {
      agentRuntimeMode,
      projectRoot: optionValue(args, "--root"),
      noIgnore: args.includes("--no-ignore"),
      allowLocalExec: args.includes("--allow-local-exec"),
      remoteProvider: agentRuntimeMode === "remote" ? remoteProvider : undefined,
      remoteEndpoint: optionValue(args, "--remote-endpoint"),
      remoteRegion: optionValue(args, "--remote-region"),
      remoteSnapshot: optionValue(args, "--remote-snapshot"),
      remoteCpu: optionValue(args, "--remote-cpu"),
      remoteMemory: optionValue(args, "--remote-memory"),
      remoteDisk: optionValue(args, "--remote-disk"),
      cloudEndpoint: optionValue(args, "--cloud-endpoint")
    }
  };
}

function parseChoice<T extends string>(value: string | undefined, allowed: readonly T[], fallback: T, label: string): T {
  if (!value) return fallback;
  if ((allowed as readonly string[]).includes(value)) return value as T;
  throw new Error(`${label} must be one of: ${allowed.join(", ")}`);
}

function learnerFeedbackTopics(state: Awaited<ReturnType<typeof loadLearnerState>>): string[] {
  const covered = new Set(state.coveredTopics.map((topic) => topic.slug));
  return [...new Set(
    state.feedback
      .map((feedback) => feedback.topic.trim())
      .filter((topic) => topic && topic !== "general" && !covered.has(topic))
  )].slice(-10);
}

async function runExportCommand(cwd: string, args: string[]): Promise<void> {
  if (!args.includes("--finetune")) {
    throw new Error([
      "export needs a mode.",
      "",
      "Recover with:",
      "  keating export --finetune",
      "  keating export --finetune --source=artifacts --format=chatml",
      "",
      "Supported options:",
      "  --source=all|artifacts|sessions",
      "  --format=chatml|alpaca|both",
      "  --out=DIR",
      "  --no-redact",
      "  --min-assistant-chars=N"
    ].join("\n"));
  }

  const source = parseChoice<ExportSource>(optionValue(args, "--source"), ["all", "artifacts", "sessions"], "all", "--source");
  const format = parseChoice<FineTuneFormat>(optionValue(args, "--format"), ["chatml", "alpaca", "both"], "both", "--format");
  const minAssistantCharsValue = optionValue(args, "--min-assistant-chars");
  const minAssistantChars = minAssistantCharsValue ? Number.parseInt(minAssistantCharsValue, 10) : 80;
  if (!Number.isInteger(minAssistantChars) || minAssistantChars < 1) {
    throw new Error("--min-assistant-chars must be a positive integer.");
  }

  const result = await exportKeatingData(cwd, {
    mode: "finetune",
    source,
    format,
    outDir: optionValue(args, "--out"),
    redact: !args.includes("--no-redact"),
    minAssistantChars,
  });

  console.log(`${color.ok}Exported ${result.manifest.counts.examplesWritten} fine-tuning examples.${color.reset}`);
  console.log(relative(cwd, result.manifestPath));
  for (const file of result.manifest.files) console.log(file);
}

async function runImportCommand(cwd: string, args: string[]): Promise<void> {
  if (!args.includes("--finetune")) {
    throw new Error([
      "import needs a mode.",
      "",
      "Recover with:",
      "  keating import --finetune .keating/outputs/exports/<export-dir>",
      "  keating import --finetune train.chatml.jsonl --format=chatml",
      "",
      "Supported options:",
      "  --format=auto|chatml|alpaca",
      "  --title=TITLE"
    ].join("\n"));
  }

  const sourcePath = firstPositional(args.filter((arg) => arg !== "--finetune"));
  if (!sourcePath) {
    throw commandUsage("import", "keating import --finetune .keating/outputs/exports/<export-dir>");
  }
  const format = parseChoice<FineTuneImportFormat>(
    optionValue(args, "--format"),
    ["auto", "chatml", "alpaca"],
    "auto",
    "--format"
  );
  const result = await importKeatingData(cwd, {
    sourcePath,
    format,
    title: optionValue(args, "--title"),
  });

  console.log(`${color.ok}Imported ${result.examplesImported} fine-tune examples into ${result.sessionsImported} Keating session${result.sessionsImported === 1 ? "" : "s"}.${color.reset}`);
  for (const sessionPath of result.sessionPaths) console.log(relative(cwd, sessionPath));
  if (result.skipped > 0) console.log(`${result.skipped} skipped`);
  for (const warning of result.warnings) console.log(`${color.sepia}${warning}${color.reset}`);
}

async function runEditCommand(cwd: string, args: string[]): Promise<void> {
  const fileArg = args[0];
  if (!fileArg) {
    throw commandUsage("edit", "keating edit src/core/lesson-plan.ts");
  }

  const backupDirValue = optionValue(args, "--backup-dir");
  const backupDir = backupDirValue ? join(cwd, backupDirValue) : undefined;

  // Read edit payload from stdin if piped, otherwise expect JSON file path
  const stdinPayload = process.stdin.isTTY
    ? null
    : await new Promise<string>((resolve) => {
        let data = "";
        process.stdin.on("data", (chunk) => { data += chunk; });
        process.stdin.on("end", () => resolve(data));
      });

  if (stdinPayload) {
    const edit = JSON.parse(stdinPayload) as { search: string; replace: string; reason?: string };
    if (!edit.search || typeof edit.replace !== "string") {
      throw new Error("stdin edit must be JSON with { search: string, replace: string, reason?: string }");
    }
    const result = await applySourceEdit(cwd, {
      file: fileArg,
      search: edit.search,
      replace: edit.replace,
      reason: edit.reason || "manual edit",
    }, backupDir);
    console.log(result.success ? `${color.ok}${result.message}${color.reset}` : `${color.err}${result.message}${color.reset}`);
    if (!result.success) process.exitCode = 1;
    return;
  }

  // Interactive mode: prompt for search and replace
  console.log(`${color.sepia}Interactive edit mode for ${fileArg}${color.reset}`);
  console.log("Paste the search block, then a line with --- then the replace block.");
  console.log("End with EOF (Ctrl+D) or a line with ===");
  console.log("");

  const rl = (await import("node:readline/promises")).createInterface({ input: process.stdin, output: process.stdout });
  const lines: string[] = [];
  for await (const line of rl) {
    if (line.trim() === "===") break;
    lines.push(line);
  }
  rl.close();

  const payload = lines.join("\n");
  const separatorIndex = payload.indexOf("\n---\n");
  if (separatorIndex === -1) {
    throw new Error("Could not find separator --- between search and replace blocks.");
  }

  const search = payload.slice(0, separatorIndex);
  const replace = payload.slice(separatorIndex + 5); // skip "\n---\n"

  const result = await applySourceEdit(cwd, {
    file: fileArg,
    search,
    replace,
    reason: "interactive edit",
  }, backupDir);

  console.log(result.success ? `${color.ok}${result.message}${color.reset}` : `${color.err}${result.message}${color.reset}`);
  if (!result.success) process.exitCode = 1;
}

async function setupProject(cwd: string, args: string[]): Promise<void> {
  const yes = args.includes("--yes") || args.includes("-y");
  const existing = await loadKeatingConfig(cwd);
  let next = {
    ...DEFAULT_KEATING_CONFIG,
    ...existing,
    pi: {
      ...DEFAULT_KEATING_CONFIG.pi,
      ...existing.pi
    },
    speech: {
      ...DEFAULT_KEATING_CONFIG.speech,
      ...existing.speech
    },
    debug: {
      ...DEFAULT_KEATING_CONFIG.debug,
      ...existing.debug
    }
  };

  if (!yes && process.stdin.isTTY && process.stdout.isTTY) {
    const { runInteractiveSetup } = await import("./setup.js");
    const answers = await runInteractiveSetup({
      runtimePreference: next.pi.runtimePreference,
      defaultProvider: next.pi.defaultProvider ?? DEFAULT_KEATING_CONFIG.pi.defaultProvider ?? "openai",
      defaultModel: next.pi.defaultModel ?? DEFAULT_KEATING_CONFIG.pi.defaultModel ?? DEFAULT_MODELS.cli.openai,
      defaultThinking: next.pi.defaultThinking ?? "medium"
    });

    if (!answers) {
      console.log(`${color.sepia}Setup cancelled.${color.reset}`);
      return;
    }

    next = {
      ...next,
      pi: {
        ...next.pi,
        ...answers
      }
    };
  } else {
    next = {
      ...next,
      pi: {
        ...next.pi,
        runtimePreference: DEFAULT_KEATING_CONFIG.pi.runtimePreference,
        defaultProvider: DEFAULT_KEATING_CONFIG.pi.defaultProvider,
        defaultModel: DEFAULT_KEATING_CONFIG.pi.defaultModel,
        defaultThinking: DEFAULT_KEATING_CONFIG.pi.defaultThinking
      }
    };
  }

  await writeKeatingConfig(cwd, next);
  console.log(`${color.ok}Wrote ${relative(cwd, configPath(cwd))}${color.reset}`);
  if (next.pi.defaultProvider === NOTORGANIC_PROVIDER_ID) {
    console.log(`Run ${color.primary}keating login${color.reset} to connect the five-minute infer:balanced capability.`);
  }
  console.log(`Run ${color.primary}keating doctor${color.reset} to verify the runtime, then ${color.primary}keating shell${color.reset}.`);
}

function formatPackageList(packages: string[]): string {
  if (packages.length === 0) {
    return [
      "No extra Pi packages configured for Keating.",
      "",
      "Try:",
      "  keating package recommended",
      "  keating package add npm:pi-subagents"
    ].join("\n");
  }

  return [
    "Extra Pi packages configured for Keating:",
    ...packages.map((pkg) => `  - ${pkg}`)
  ].join("\n");
}

async function runPackageCommand(cwd: string, args: string[]): Promise<void> {
  const subcommand = args[0] ?? "list";
  if (subcommand === "list") {
    console.log(formatPackageList(await listConfiguredPiPackages(cwd)));
    return;
  }

  if (subcommand === "recommended" || subcommand === "recommend") {
    console.log(recommendedPiPackagesMarkdown());
    return;
  }

  if (subcommand === "add") {
    const source = args.slice(1).join(" ").trim();
    if (!source) throw commandUsage("package add", "keating package add npm:pi-subagents");
    const packages = await addConfiguredPiPackage(cwd, source);
    console.log(`${color.ok}Added ${source} to ${relative(cwd, configPath(cwd))}.${color.reset}`);
    console.log(formatPackageList(packages));
    console.log(`${color.sepia}Packages sync into Pi settings the next time you run keating shell.${color.reset}`);
    return;
  }

  if (subcommand === "remove" || subcommand === "rm") {
    const source = args.slice(1).join(" ").trim();
    if (!source) throw commandUsage("package remove", "keating package remove npm:pi-subagents");
    const packages = await removeConfiguredPiPackage(cwd, source);
    console.log(`${color.ok}Removed ${source} from ${relative(cwd, configPath(cwd))}.${color.reset}`);
    console.log(formatPackageList(packages));
    return;
  }

  throw new Error([
    `Unknown package command: ${subcommand}`,
    "",
    "Recover with:",
    "  keating package list",
    "  keating package recommended",
    "  keating package add npm:pi-subagents",
    "  keating package remove npm:pi-subagents"
  ].join("\n"));
}

async function run(): Promise<void> {
  const cwd = process.cwd();
  await withLearnerProfileArgs(cwd, process.argv.slice(2), async (args) => {
    // One CLI process has one selected learner. Keep it available to terminal I/O
    // callbacks whose async resource may have been created before command dispatch.
    // Library callers still use isolated async contexts without changing process.env.
    const env = learnerProfileEnvironment(cwd, process.env);
    process.env.KEATING_LEARNER_PROFILE = env.KEATING_LEARNER_PROFILE ?? "";
    process.env.KEATING_LEARNER_PROFILE_CWD = env.KEATING_LEARNER_PROFILE_CWD ?? "";
    await runSelectedCommand(args);
  });
}

async function runSelectedCommand(rawArgs: string[]): Promise<void> {
  const cwd = process.cwd();
  if (rawArgs.length === 1 && (rawArgs[0] === "--version" || rawArgs[0] === "-v" || rawArgs[0] === "version")) {
    console.log(`keating ${KEATING_VERSION}`);
    return;
  }
  const topLevelShellArgs = normalizeTopLevelShellArgs(rawArgs);
  if (topLevelShellArgs) {
    const exitCode = await launchAccountSyncedShell(cwd, topLevelShellArgs, launchShell);
    process.exitCode = exitCode;
    return;
  }

  const [command = "shell", ...args] = rawArgs;

  switch (command) {
    case "sync": {
      const action = args[0] ?? "run";
      if (args.includes("--help") || args.includes("-h")) {
        console.log("Usage: keating sync [login [--manual]|logout|status|list|open <id>|add <file>]\nConnect once with sync login. New shell conversations sync before and after each session. Add a local Pi JSONL explicitly to share it with this account.");
        return;
      }
      if (!["run", "login", "logout", "status", "list", "open", "add"].includes(action)) throw new Error("Unknown sync action. Run `keating sync --help`.");
      if (action === "open") {
        if (args.length !== 2) throw new Error("Usage: keating sync open <conversation-id>");
        const local = await currentCliAccountSyncLocal(cwd);
        const session = (await local.list()).find(item => item.data.id === args[1]);
        if (!session) throw new Error("Conversation not found. Run `keating sync list` to see exact IDs.");
        process.exitCode = await launchAccountSyncedShell(cwd, ["--session", accountSyncSessionPath(local.directory, session.data.id)], launchShell);
        return;
      }
      await withAccountSyncLease(cwd, async () => {
        if (action === "login") {
          if (args.slice(1).some(arg => !["--manual", "--headless"].includes(arg))) throw new Error("Usage: keating sync login [--manual]");
          const manual = shouldUseManualLogin(args);
          const result = await loginAccountSync(cwd, { onAuth: ({ url, instructions }) => { if (instructions) console.log(instructions); console.log(url); if (!manual) openAuthorizationUrl(url); }, ...(manual ? { onManualCodeInput: readManualCallback } : {}) });
          console.log(`Account sync connected: ${result.did}.`);
          await syncCliAccount(cwd, console.log);
          return;
        }
        if (action === "add") {
          if (args.length !== 2) throw new Error("Usage: keating sync add <Pi-session.jsonl>");
          const local = await currentCliAccountSyncLocal(cwd);
          const id = await local.adopt(args[1]!);
          console.log(`Added conversation ${id} to this account.`);
          await syncCliAccount(cwd, console.log);
          return;
        }
        if (args.length > 1) throw new Error("Unexpected sync arguments. Run `keating sync --help`.");
        if (action === "logout") { console.log(await logoutAccountSync(cwd) ? "Account sync disconnected." : "Account sync disconnected locally. Remote revocation could not be confirmed."); return; }
        if (action === "status") {
          const credential = await loadAccountSyncCredential(cwd);
          console.log(credential ? `${credential.did} · ${credential.refreshExpiresAt > Date.now() ? "connected" : "reconnect required"} · ${credential.issuer}` : "Account sync is disconnected. Run `keating sync login`.");
          return;
        }
        if (action === "list") {
          try { await syncCliAccount(cwd, console.log); }
          catch (error) { console.error(`Showing conversations saved on this device: ${error instanceof Error ? error.message : "sync unavailable"}`); }
          for (const session of await (await currentCliAccountSyncLocal(cwd)).list()) console.log(`${session.data.id}\t${session.data.title}\t${session.data.lastModified}`);
        } else await syncCliAccount(cwd, console.log);
      });
      return;
    }
    case "login": {
      await runLoginCommand(cwd, args);
      return;
    }
    case "logout": {
      runLogoutCommand(cwd, args);
      return;
    }
    case "auth": {
      const subcommand = args[0] ?? "status";
      if (subcommand !== "status") throw commandUsage("auth", "keating auth status");
      printNotOrganicStatus(cwd);
      return;
    }
    case "setup": {
      await setupProject(cwd, args);
      return;
    }
    case "profile": {
      const { runProfileCommand } = await import("./profile.js");
      await runProfileCommand(cwd, args);
      return;
    }
    case "package":
    case "packages": {
      await runPackageCommand(cwd, args);
      return;
    }
    case "web": {
      if (args.includes("--help") || args.includes("-h")) {
        console.log(webHelpText());
        return;
      }
      const { port, options } = parseWebCommand(args);
      await serveWeb(port, { ...options, projectRoot: options.projectRoot ?? cwd });
      return;
    }
    case "webmcp": {
      const portArg = firstPositional(args);
      const port = portArg ? parseInt(portArg, 10) : 3928;
      const host = optionValue(args, "--host") ?? "127.0.0.1";
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error(`Invalid port: "${portArg}". Must be an integer between 1 and 65535.`);
      }
      const running = await serveWebMcp({ cwd, port, host });
      console.log(`${color.ok}${color.bold} Keating WebMCP ${color.reset}  ${color.parchment}${running.url}${color.reset}`);
      console.log(`${color.sepia}Connect MCP clients to the URL above. Press Ctrl+C to stop.${color.reset}`);
      return;
    }
    case "shell": {
      const exitCode = await launchAccountSyncedShell(cwd, args, launchShell);
      process.exitCode = exitCode;
      return;
    }
    case "tui": {
      const result = await launchAccountSyncedShell(cwd, [], async (selectedCwd, sessionArgs) => {
        const directoryIndex = sessionArgs.lastIndexOf("--session-dir");
        const accountDirectory = directoryIndex >= 0 ? sessionArgs[directoryIndex + 1] : undefined;
        return launchOpenTui(selectedCwd, args.join(" ").trim() || undefined, {
          sessionArgs,
          ...(accountDirectory ? { listSessions: async () => {
            const { SessionManager } = await import("@earendil-works/pi-coding-agent");
            return SessionManager.list(selectedCwd, accountDirectory);
          } } : {}),
        });
      });
      if (result.action === "shell") {
        const exitCode = await launchAccountSyncedShell(cwd, shellHandoffArgs(result), launchShell);
        process.exitCode = exitCode;
      }
      return;
    }
    case "plan": {
      const topic = args.join(" ").trim();
      if (!topic) throw commandUsage("plan", "keating plan derivative");
      const artifact = await planTopicArtifact(cwd, topic);
      console.log(relative(cwd, artifact.planPath));
      console.log(artifact.reviewPath ? `Lesson plan review (${artifact.reviewStatus}): ${relative(cwd, artifact.reviewPath)}` : `Lesson plan review: ${artifact.reviewStatus}. Opt in with KEATING_LESSON_PLAN_JUDGE=notorganic.`);
      return;
    }
    case "map": {
      const topic = args.join(" ").trim();
      if (!topic) throw commandUsage("map", "keating map derivative");
      const artifact = await mapTopicArtifact(cwd, topic);
      console.log(relative(cwd, artifact.mmdPath));
      return;
    }
    case "animate": {
      const topic = args.join(" ").trim();
      if (!topic) throw commandUsage("animate", "keating animate derivative");
      const artifact = await animateTopicArtifact(cwd, topic);
      console.log(relative(cwd, artifact.playerPath));
      console.log(relative(cwd, artifact.scenePath));
      console.log(relative(cwd, artifact.storyboardPath));
      console.log(relative(cwd, artifact.manifestPath));
      return;
    }
    case "verify": {
      const topic = args.join(" ").trim();
      if (!topic) throw commandUsage("verify", "keating verify derivative");
      const result = await verifyTopicArtifact(cwd, topic);
      if (result.alreadyVerified) {
        console.log(`Already verified: ${relative(cwd, result.checklistPath)}`);
      } else {
        console.log(`Verification checklist: ${relative(cwd, result.checklistPath)}`);
      }
      return;
    }
    case "quiz": {
      const topic = args.join(" ").trim();
      if (!topic) throw commandUsage("quiz", "keating quiz derivative");
      const result = await quizTopicArtifact(cwd, topic);
      console.log(relative(cwd, result.quizPath));
      console.log(relative(cwd, result.answersPath));
      return;
    }
    case "bench": {
      const topic = args.join(" ").trim() || undefined;
      const result = await benchPolicyArtifact(cwd, topic);
      console.log(`${result.overallScore.toFixed(2)} ${relative(cwd, result.reportPath)}`);
      if (result.tracePath) console.log(relative(cwd, result.tracePath));
      return;
    }
    case "openui-diagnostics": {
      runOpenUiDiagnosticCommand(args);
      return;
    }
    case "teaching-bench": {
      if (args.includes("--help") || args.includes("-h")) { console.log(teachingCommandHelp("teaching-bench")); return; }
      const options = await teachingCommandOptions(cwd, args, "teaching-bench");
      const { report, reportPath, judgement } = await teachingBenchmarkArtifact(cwd, options);
      if (judgement) console.log(`Judge: ${judgement.backend.model}; ${judgement.calibration} proxy estimates.`);
      console.log(`Training behavior score: ${report.meanScore === null ? "unavailable" : `${(report.meanScore * 100).toFixed(2)}%`}; execution errors: ${report.errorCount}.`);
      console.log("Evidence: synthetic cases and executed tutor behavior. Human learning: unmeasured. This command cannot promote a revision.");
      console.log(relative(cwd, reportPath));
      if (report.errorCount) process.exitCode = 1;
      return;
    }
    case "learning-check": {
      await runLearningCheckCommand(cwd, args);
      return;
    }
    case "evolve": {
      const topic = args.join(" ").trim() || undefined;
      const result = await evolvePolicyArtifact(cwd, topic);
      console.log(`Unvalidated proposals saved; active policy unchanged. ${relative(cwd, result.reportPath)}`);
      if (result.tracePath) console.log(relative(cwd, result.tracePath));
      return;
    }
    case "prompt-evolve": {
      const promptName = args.join(" ").trim() || "learn";
      const result = await evolvePromptArtifact(cwd, promptName);
      console.log(`${result.bestScore.toFixed(2)} ${relative(cwd, result.reportPath)}`);
      console.log(relative(cwd, result.evolvedPromptPath));
      return;
    }
    case "prompt-eval": {
      const promptContent = args.join(" ").trim();
      if (!promptContent) throw commandUsage("prompt-eval", "keating prompt-eval \"Start with a diagnostic question.\"");
      const result = await promptEvalArtifact(cwd, promptContent);
      console.log(`${result.score.toFixed(2)} ${relative(cwd, result.reportPath)}`);
      return;
    }
    case "improve": {
      if (args[0] === "history") {
        const md = await improveHistory(cwd);
        console.log(md);
        return;
      }
      if (args[0] === "accept") {
        const proposalId = args[1];
        if (!proposalId) throw commandUsage("improve accept", "keating improve accept improve-abc123");
        const result = await improveAccept(cwd, proposalId);
        console.log(`${color.ok}Accepted ${proposalId}.${color.reset} After: ${result.afterScore.toFixed(2)} Delta: ${result.delta >= 0 ? "+" : ""}${result.delta.toFixed(2)}`);
        return;
      }
      if (args[0] === "reject") {
        const proposalId = args[1];
        if (!proposalId) throw commandUsage("improve reject", "keating improve reject improve-abc123");
        await improveReject(cwd, proposalId);
        console.log(`${color.ok}Rejected ${proposalId} and restored snapshots when available.${color.reset}`);
        return;
      }
      const artifact = await improveArtifact(cwd);
      console.log(`Proposal: ${artifact.proposal.id}`);
      console.log(`Targets: ${artifact.proposal.targets.map(t => t.file).join(", ")}`);
      console.log(relative(cwd, artifact.proposalPath));
      return;
    }
    case "auto-improve": {
      if (args.includes("--help") || args.includes("-h")) { console.log(teachingCommandHelp("auto-improve")); return; }
      const options = await teachingCommandOptions(cwd, args, "auto-improve");
      const result = await autoImproveArtifact(cwd, undefined, options);
      const score = (value: number | null) => value === null ? "unavailable" : value.toFixed(2);
      console.log(`Teaching experiment: ${result.status.toUpperCase()}.`);
      if (result.judgement) console.log(`Judge: ${result.judgement.backend.model}; ${result.judgement.calibration} proxy estimates.`);
      console.log(`Behavior scores: ${score(result.baselineScore)} → ${score(result.afterScore)}; delta: ${score(result.delta)}.`);
      console.log(result.status === "accepted" ? "Both independent gates passed; the candidate applies to subsequent sessions."
        : "The active teaching revision is unchanged.");
      console.log("Human learning, retention, and transfer: unmeasured. A higher behavior score alone does not authorize promotion.");
      if (result.experiment.reasons.length) console.log(`Decision: ${result.experiment.reasons.join(", ")}`);
      console.log(relative(cwd, result.reportPath));
      console.log(relative(cwd, result.observabilityPath));
      if (result.status === "failed") process.exitCode = 1;
      return;
    }
    case "edit": {
      await runEditCommand(cwd, args);
      return;
    }
    case "export": {
      await runExportCommand(cwd, args);
      return;
    }
    case "import": {
      await runImportCommand(cwd, args);
      return;
    }
    case "policy": {
      await ensureProjectScaffold(cwd);
      console.log(await currentPolicySummary(cwd));
      return;
    }
    case "trace": {
      await ensureProjectScaffold(cwd);
      const query = args.join(" ").trim().toLowerCase();
      const artifacts = await listArtifacts(cwd);
      for (const artifact of artifacts) {
        if (!query || artifact.path.toLowerCase().includes(query) || artifact.label.toLowerCase().includes(query)) {
          console.log(artifact.path);
        }
      }
      return;
    }
    case "learner-state": {
      await ensureProjectScaffold(cwd);
      const statePath = learnerStatePath(cwd);
      const state = await loadLearnerState(statePath);
      const upCount = state.feedback.filter((f) => f.signal === "thumbs-up").length;
      const downCount = state.feedback.filter((f) => f.signal === "thumbs-down").length;
      const confusedCount = state.feedback.filter((f) => f.signal === "confused").length;
      console.log(`${bold("primary", "Learner Profile")}`);
      console.log(`  Sessions: ${state.sessions?.length ?? 0}`);
      console.log(`  Topics covered: ${state.coveredTopics.length}`);
      for (const t of state.coveredTopics.slice(-10)) console.log(`    - ${t.slug} (${t.domain})`);
      const feedbackTopics = learnerFeedbackTopics(state);
      if (feedbackTopics.length > 0) {
        console.log(`  Feedback-only topics: ${feedbackTopics.length}`);
        for (const topic of feedbackTopics) console.log(`    - ${topic}`);
      }
      console.log(`  Feedback: 👍${upCount} 👎${downCount} 🤔${confusedCount}`);
      console.log(`  Misconceptions identified: ${state.identifiedMisconceptions.length}`);
      return;
    }
    case "timeline": {
      const { markdown } = await timelineArtifact(cwd);
      console.log(markdown);
      return;
    }
    case "due": {
      if (args.some(arg => arg !== "--readiness")) throw new Error("Usage: keating due [--readiness]");
      const { markdown } = await dueTopicsArtifact(cwd, { readiness: args.includes("--readiness") });
      console.log(markdown);
      return;
    }
    case "feedback": {
      await ensureProjectScaffold(cwd);
      const signalMap: Record<string, "thumbs-up" | "thumbs-down" | "confused"> = {
        up: "thumbs-up",
        down: "thumbs-down",
        confused: "confused"
      };
      const signal = signalMap[args[0]?.toLowerCase() ?? ""];
      if (!signal) {
        throw new Error([
          "feedback needs a signal: up, down, or confused.",
          "",
          "Recover with:",
          "  keating feedback up derivative",
          "  keating feedback confused derivative --comment=\"lost at chain rule\""
        ].join("\n"));
      }
      let comment: string | undefined;
      const filtered = args.filter((arg) => {
        if (arg.startsWith("--comment=")) {
          comment = arg.slice("--comment=".length);
          return false;
        }
        return true;
      });
      const topic = filtered.slice(1).join(" ") || "general";
      const statePath = learnerStatePath(cwd);
      const state = await loadLearnerState(statePath);
      recordFeedback(state, topic, signal, comment);
      await saveLearnerState(statePath, state);
      const sigLabel = { "thumbs-up": "👍 up", "thumbs-down": "👎 down", "confused": "🤔 confused" }[signal];
      const commentHint = comment ? ` (comment: "${comment}")` : "";
      console.log(`${color.ok}Recorded ${sigLabel} feedback for "${topic}"${commentHint}.${color.reset}`);
      return;
    }
    case "doctor": {
      await ensureProjectScaffold(cwd);
      const config = await loadKeatingConfig(cwd);
      const runtime = await detectAiRuntime(cwd);
      console.log(`${bold("primary", "Keating Doctor")}  ${color.sepia}diagnostic report${color.reset}\n`);
      console.log(`  ${color.cream}config_path${color.reset}           ${color.sepia}${configPath(cwd)}${color.reset}`);
      console.log(`  ${color.cream}ai_runtime_preference${color.reset} ${color.primary}${config.pi.runtimePreference}${color.reset}`);
      console.log(`  ${color.cream}ai_default_provider${color.reset}   ${config.pi.defaultProvider ?? color.sepia + "unset" + color.reset}`);
      console.log(`  ${color.cream}ai_default_model${color.reset}      ${config.pi.defaultModel ?? color.sepia + "unset" + color.reset}`);
      console.log(`  ${color.cream}ai_default_thinking${color.reset}   ${config.pi.defaultThinking ?? color.sepia + "unset" + color.reset}`);
      const hostedStatus = notOrganicAuthStatus(cwd);
      const hostedLabel = hostedStatus.expired
        ? `${color.err}expired (run keating login)${color.reset}`
        : hostedStatus.configured
          ? `${color.ok}connected · ${hostedStatus.secondsRemaining ?? 0}s remaining${color.reset}`
          : `${color.sepia}not connected${color.reset}`;
      console.log(`  ${color.cream}ai_notorganic${color.reset}         ${hostedLabel}`);
      console.log(`  ${color.cream}debug_persist_traces${color.reset}  ${color.primary}${String(config.debug.persistTraces)}${color.reset}`);
      console.log(`  ${color.cream}debug_trace_top_learners${color.reset} ${color.primary}${String(config.debug.traceTopLearners)}${color.reset}`);
      console.log(`  ${color.cream}debug_console_summary${color.reset} ${color.primary}${String(config.debug.consoleSummary)}${color.reset}`);
      console.log(`  ${color.cream}ai_runtime${color.reset}            ${runtime.selected ? color.ok + runtime.selected.kind : color.err + "missing"}${color.reset}`);
      console.log(`  ${color.cream}ai_standalone${color.reset}         ${runtime.standalone ? color.primary + runtime.standalone.command : color.err + "missing"}${color.reset}`);
      console.log(`  ${color.cream}ai_embedded${color.reset}           ${runtime.embedded ? color.primary + (runtime.embedded.cliPath ?? runtime.embedded.command) : color.err + "missing"}${color.reset}`);
      if (runtime.selected) console.log(`  ${color.cream}ai_command${color.reset}            ${color.primary}${runtime.selected.command}${color.reset}`);
      console.log(`  ${color.cream}map_renderer${color.reset}          ${color.ok}mermaid-source${color.reset}`);
      console.log(`  ${color.cream}animation_renderer${color.reset}    ${color.ok}hyperframes${color.reset}`);
      return;
    }
    case "help":
    case "--help":
    case "-h": {
      printUsage();
      return;
    }
    default: {
      throw unknownCommand(command);
    }
  }
}

run().catch((error) => {
  console.error(`${color.err}${color.bold}Error:${color.reset} ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
